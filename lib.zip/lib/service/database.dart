import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static final _dbName = "sensorData.db";
  static final _dbVersion = 1;
  static final table = 'scans';

  DatabaseHelper._privateConstructor();
  static final DatabaseHelper instance = DatabaseHelper._privateConstructor();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  _initDatabase() async {
    String path = join(await getDatabasesPath(), _dbName);
    return await openDatabase(path,
        version: _dbVersion,
        onCreate: (db, version) async {
          await db.execute('''
        CREATE TABLE $table(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          temperature REAL,
          humidity REAL,
          gasVOC REAL,
          verdict TEXT,
          reason TEXT,
          timestamp TEXT
        )
      ''');
        });
  }

  Future<int> insert(Map<String, dynamic> row) async {
    Database db = await instance.database;
    return await db.insert(table, row,
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<Map<String, dynamic>>> queryAll() async {
    Database db = await instance.database;
    return await db.query(table, orderBy: "timestamp DESC");
  }
  // Add this inside your DatabaseHelper class
  Future<List<Map<String, dynamic>>> getHistory() async {
    final db = await instance.database;
    final result = await db!.query('sensorData.db"');
    print("SQLite Rows Found: ${result.length}"); // <--- ADD THIS LINE
    return result;
  }
  // Add this inside your DatabaseHelper class
  Future<int> deleteAll() async {
    Database? db = await instance.database;
    // This deletes all rows from your specific table
    return await db!.delete('sensor_table');
  }
}
