import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:firebase_database/firebase_database.dart';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:firebase_database/firebase_database.dart';
import 'package:csv/csv.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import '../service/database.dart'; // <--- Double check this path matches your folder!
Future<void> _handleExport(BuildContext context) async {
  try {
    List<Map<String, dynamic>> data = [];

    if (kIsWeb) {
      // 🌐 IF ON CHROME: Fetch from Firebase instead of SQLite
      final ref = FirebaseDatabase.instance.ref("sensor_history");
      final snapshot = await ref.get();
      if (snapshot.exists) {
        Map<dynamic, dynamic> map = snapshot.value as Map<dynamic, dynamic>;
        map.forEach((key, value) => data.add(Map<String, dynamic>.from(value)));
      }
    } else {
      // 📱 IF ON PHONE: Fetch from SQLite
      data = await DatabaseHelper.instance.queryAll();
    }

    if (data.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("No history data found to export!")),
      );
      return;
    }

    // --- CSV Generation (Same as before) ---
    List<List<dynamic>> rows = [];
    rows.add(["Verdict", "Temp", "Humidity", "Gas", "Timestamp"]);
    for (var scan in data) {
      rows.add([scan['verdict'], scan['temperature'], scan['humidity'], scan['gasVOC'],   scan['timestamp']]);
    }

    String csvString = const ListToCsvConverter().convert(rows);

    if (kIsWeb) {
      // 🌐 WEB DOWNLOAD LOGIC (Browsers don't "share" files, they download them)
      // This requires a small trick to trigger a browser download
      print("CSV Ready for Web: $csvString");
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Web export logic requires 'dart:html' or 'printing' package")),
      );
    } else {
      // 📱 MOBILE SHARE LOGIC
      final directory = await getTemporaryDirectory();
      final File file = File("${directory.path}/Sensor_Report.csv");
      await file.writeAsString(csvString);
      await Share.shareXFiles([XFile(file.path)], text: 'Sensor Data');
    }

  } catch (e) {
    print("Error: $e");
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Export Error: ${e.toString()}")),
    );
  }
}