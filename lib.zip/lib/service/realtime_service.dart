import 'package:firebase_database/firebase_database.dart';

class RealtimeService {
  final DatabaseReference _ref =
      FirebaseDatabase.instance.ref("sensorData");

  Stream<DatabaseEvent> getSensorData() {
    return _ref.onValue;
  }
}
