String classifyFruit(int r, int g, int b, int gas) {
  if (gas > 500) return "NOT SAFE";
  if (gas > 300) return "WARNING";
  return "SAFE";
}
