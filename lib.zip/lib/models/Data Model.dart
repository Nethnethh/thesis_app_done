class SensorData {
  int r, g, b, gas;
  String status;

  SensorData(this.r, this.g, this.b, this.gas, this.status);
}
